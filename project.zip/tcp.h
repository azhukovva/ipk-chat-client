#ifndef TCP_H
#define TCP_H

#include "libs.h"

int tcp_connect(char *server_ip, int port);

#endif